package com.ibm.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Order {

	@Id
	@GeneratedValue
	private int oid;
	@Column
	private int quantity;
	@Column(name="txn_type", length=8)
	private String txnType;
	@Column(name="txn_date")
	private LocalDate txnDate;
	@Column
	private Stock share;
	@Column
	private Portfolio portfolio;
	
}
