package com.ibm.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Portfolio {

	@Id
	private int pid;
	@Column(length=25)
	private String holder;
	@Column
	private double investment;
	
	private List<Order> orders = new ArrayList<>();
}
