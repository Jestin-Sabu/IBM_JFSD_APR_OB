package com.ibm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Stock {

	@Id
	private int sid;
	@Column(length=20)
	private String company;
	@Column
	private double quote;
}
